exports.handler=async(event)=>{
try{
 const body=JSON.parse(event.body||'{}');
 const secret=(event.headers['x-webhook-secret']||event.headers['X-Webhook-Secret']||'');
 if(secret!=='devan1234') return {statusCode:401,body:JSON.stringify({error:'Unauthorized'})};
 const status=(body.status||'pending').toLowerCase();
 return {statusCode:200,body:JSON.stringify({received:true,status,message:status==='completed'?'Activate user':'Pending or failed'})};
}catch(e){return {statusCode:500,body:JSON.stringify({error:e.message})}}
}