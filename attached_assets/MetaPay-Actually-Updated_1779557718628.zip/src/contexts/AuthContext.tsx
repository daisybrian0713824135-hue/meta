import React,{createContext,useContext,useEffect,useState} from 'react';
const AuthContext=createContext<any>(null);
export const useAuth=()=>useContext(AuthContext);
export const AuthProvider=({children}:any)=>{
 const [user,setUser]=useState<any>(null); const [loading,setLoading]=useState(true);
 useEffect(()=>{
  const s=JSON.parse(localStorage.getItem('metapay_session')||'null');
  setUser(s); setLoading(false);
 },[]);
 const signOut=async()=>{localStorage.removeItem('metapay_session'); setUser(null); window.location.href='/login';}
 const profile=user?{username:user.username,full_name:user.username,role:user.role||'user',status:user.status||'active',withdrawal_balance:0,package:null}:null;
 return <AuthContext.Provider value={{user,session:user,profile,loading,signOut,refreshProfile:async()=>{},isAdmin:profile?.role!=='user',isActive:true,setUser}}>{children}</AuthContext.Provider>
}
