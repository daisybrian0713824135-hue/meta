export const TASKS=[
  {
    "id": 1,
    "title": "YouTube Watch Task #1",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 2,
    "title": "YouTube Watch Task #2",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 3,
    "title": "YouTube Watch Task #3",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 4,
    "title": "YouTube Watch Task #4",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 5,
    "title": "YouTube Watch Task #5",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 6,
    "title": "YouTube Watch Task #6",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 7,
    "title": "YouTube Watch Task #7",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 8,
    "title": "YouTube Watch Task #8",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 9,
    "title": "YouTube Watch Task #9",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 10,
    "title": "YouTube Watch Task #10",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 11,
    "title": "YouTube Watch Task #11",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 12,
    "title": "YouTube Watch Task #12",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 13,
    "title": "YouTube Watch Task #13",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 14,
    "title": "YouTube Watch Task #14",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 15,
    "title": "YouTube Watch Task #15",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 16,
    "title": "YouTube Watch Task #16",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 17,
    "title": "YouTube Watch Task #17",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 18,
    "title": "YouTube Watch Task #18",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 19,
    "title": "YouTube Watch Task #19",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 20,
    "title": "YouTube Watch Task #20",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 21,
    "title": "YouTube Watch Task #21",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 22,
    "title": "YouTube Watch Task #22",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 23,
    "title": "YouTube Watch Task #23",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 24,
    "title": "YouTube Watch Task #24",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 25,
    "title": "YouTube Watch Task #25",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 26,
    "title": "YouTube Watch Task #26",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 27,
    "title": "YouTube Watch Task #27",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 28,
    "title": "YouTube Watch Task #28",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 29,
    "title": "YouTube Watch Task #29",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 30,
    "title": "YouTube Watch Task #30",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 31,
    "title": "YouTube Watch Task #31",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 32,
    "title": "YouTube Watch Task #32",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 33,
    "title": "YouTube Watch Task #33",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 34,
    "title": "YouTube Watch Task #34",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 35,
    "title": "YouTube Watch Task #35",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 36,
    "title": "YouTube Watch Task #36",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 37,
    "title": "YouTube Watch Task #37",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 38,
    "title": "YouTube Watch Task #38",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 39,
    "title": "YouTube Watch Task #39",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 40,
    "title": "YouTube Watch Task #40",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 41,
    "title": "YouTube Watch Task #41",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 42,
    "title": "YouTube Watch Task #42",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 43,
    "title": "YouTube Watch Task #43",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 44,
    "title": "YouTube Watch Task #44",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 45,
    "title": "YouTube Watch Task #45",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 46,
    "title": "YouTube Watch Task #46",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 47,
    "title": "YouTube Watch Task #47",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 48,
    "title": "YouTube Watch Task #48",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 49,
    "title": "YouTube Watch Task #49",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 50,
    "title": "YouTube Watch Task #50",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 51,
    "title": "YouTube Watch Task #51",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 52,
    "title": "YouTube Watch Task #52",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 53,
    "title": "YouTube Watch Task #53",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 54,
    "title": "YouTube Watch Task #54",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 55,
    "title": "YouTube Watch Task #55",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 56,
    "title": "YouTube Watch Task #56",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 57,
    "title": "YouTube Watch Task #57",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 58,
    "title": "YouTube Watch Task #58",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 59,
    "title": "YouTube Watch Task #59",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 60,
    "title": "YouTube Watch Task #60",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 61,
    "title": "YouTube Watch Task #61",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 62,
    "title": "YouTube Watch Task #62",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 63,
    "title": "YouTube Watch Task #63",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 64,
    "title": "YouTube Watch Task #64",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 65,
    "title": "YouTube Watch Task #65",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 66,
    "title": "YouTube Watch Task #66",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 67,
    "title": "YouTube Watch Task #67",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 68,
    "title": "YouTube Watch Task #68",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 69,
    "title": "YouTube Watch Task #69",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 70,
    "title": "YouTube Watch Task #70",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 71,
    "title": "YouTube Watch Task #71",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 72,
    "title": "YouTube Watch Task #72",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 73,
    "title": "YouTube Watch Task #73",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 74,
    "title": "YouTube Watch Task #74",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 75,
    "title": "YouTube Watch Task #75",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 76,
    "title": "YouTube Watch Task #76",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 77,
    "title": "YouTube Watch Task #77",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 78,
    "title": "YouTube Watch Task #78",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 79,
    "title": "YouTube Watch Task #79",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 80,
    "title": "YouTube Watch Task #80",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 81,
    "title": "YouTube Watch Task #81",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 82,
    "title": "YouTube Watch Task #82",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 83,
    "title": "YouTube Watch Task #83",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 84,
    "title": "YouTube Watch Task #84",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 85,
    "title": "YouTube Watch Task #85",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 86,
    "title": "YouTube Watch Task #86",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 87,
    "title": "YouTube Watch Task #87",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 88,
    "title": "YouTube Watch Task #88",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 89,
    "title": "YouTube Watch Task #89",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 90,
    "title": "YouTube Watch Task #90",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 91,
    "title": "YouTube Watch Task #91",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 92,
    "title": "YouTube Watch Task #92",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 93,
    "title": "YouTube Watch Task #93",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 94,
    "title": "YouTube Watch Task #94",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 95,
    "title": "YouTube Watch Task #95",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 96,
    "title": "YouTube Watch Task #96",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 97,
    "title": "YouTube Watch Task #97",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 98,
    "title": "YouTube Watch Task #98",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 99,
    "title": "YouTube Watch Task #99",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 100,
    "title": "YouTube Watch Task #100",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 101,
    "title": "YouTube Watch Task #101",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 102,
    "title": "YouTube Watch Task #102",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 103,
    "title": "YouTube Watch Task #103",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 104,
    "title": "YouTube Watch Task #104",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 105,
    "title": "YouTube Watch Task #105",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 106,
    "title": "YouTube Watch Task #106",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 107,
    "title": "YouTube Watch Task #107",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 108,
    "title": "YouTube Watch Task #108",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 109,
    "title": "YouTube Watch Task #109",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 110,
    "title": "YouTube Watch Task #110",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 111,
    "title": "YouTube Watch Task #111",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 112,
    "title": "YouTube Watch Task #112",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 113,
    "title": "YouTube Watch Task #113",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 114,
    "title": "YouTube Watch Task #114",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 115,
    "title": "YouTube Watch Task #115",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 116,
    "title": "YouTube Watch Task #116",
    "reward": 25,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 117,
    "title": "YouTube Watch Task #117",
    "reward": 30,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 118,
    "title": "YouTube Watch Task #118",
    "reward": 35,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 119,
    "title": "YouTube Watch Task #119",
    "reward": 40,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  },
  {
    "id": 120,
    "title": "YouTube Watch Task #120",
    "reward": 20,
    "category": "video_tasks",
    "url": "https://youtube.com",
    "description": "Watch and engage with a video"
  }
];