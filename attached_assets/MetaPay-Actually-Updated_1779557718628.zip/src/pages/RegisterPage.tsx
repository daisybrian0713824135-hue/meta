import React,{useState} from 'react';
import {Link,useNavigate} from 'react-router-dom';
import {motion} from 'framer-motion';
import {Eye,EyeOff,Zap,UserPlus} from 'lucide-react';
import {register} from '@/db/firebaseAuth';
import {useAuth} from '@/contexts/AuthContext';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {toast} from 'sonner';
const RegisterPage=()=>{const nav=useNavigate(); const {setUser}=useAuth(); const [show,setShow]=useState(false); const [f,setF]=useState({username:'',phone:'',password:''}); const [loading,setLoading]=useState(false);
const s=async(e:any)=>{e.preventDefault(); setLoading(true); const r=await register(f.username,f.password,f.phone); if(r.error){toast.error(r.error.message); setLoading(false); return;} setUser(r.user); toast.success('Account created'); nav('/dashboard',{replace:true})}
return <div className='min-h-screen flex items-center justify-center bg-background'><motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className='w-full max-w-md bg-card border rounded-2xl p-8 shadow-xl'><div className='text-center mb-6'><div className='flex justify-center items-center gap-2 text-2xl font-bold'><Zap/>MetaPay</div><p>Create account</p></div><form onSubmit={s} className='space-y-4'><Input placeholder='Username' value={f.username} onChange={e=>setF({...f,username:e.target.value})}/><Input placeholder='Phone Number' value={f.phone} onChange={e=>setF({...f,phone:e.target.value})}/><div className='relative'><Input type={show?'text':'password'} placeholder='Password' value={f.password} onChange={e=>setF({...f,password:e.target.value})}/><button type='button' className='absolute right-3 top-3' onClick={()=>setShow(!show)}>{show?<EyeOff size={16}/>:<Eye size={16}/>}</button></div><Button className='w-full' disabled={loading}>{loading?'Creating...':<span className='flex gap-2 items-center'><UserPlus size={16}/>Register</span>}</Button></form><p className='mt-4 text-center text-sm'>Have account? <Link to='/login' className='text-primary'>Login</Link></p></motion.div></div>}
export default RegisterPage;
