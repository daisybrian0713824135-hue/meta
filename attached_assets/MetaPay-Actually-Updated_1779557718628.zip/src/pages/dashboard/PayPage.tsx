import React from "react";
import {useSearchParams} from "react-router-dom";
import DashboardLayout from "@/components/layouts/DashboardLayout";
export default function Pay(){
const [sp]=useSearchParams();
const pkg=sp.get('pkg')||'Starter';
return <DashboardLayout>
<h1 className="text-2xl font-bold mb-4">PayNecta Payment - {pkg}</h1>
<p className="mb-4">Complete payment below. Your account remains inactive until webhook verification confirms payment.</p>
<iframe src="https://paynecta.co.ke/pay/metapay-agencies" className="w-full h-[600px] border rounded-xl"></iframe>
<div className="mt-4 p-4 rounded-xl border">
<p className="font-medium">Payment Status: Pending Verification</p>
<p className="text-sm opacity-80">After successful PayNecta payment, webhook verification activates your account automatically.</p>
</div>
</DashboardLayout>}
