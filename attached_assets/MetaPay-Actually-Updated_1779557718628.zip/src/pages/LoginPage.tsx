import React,{useState} from 'react';
import {Link,useNavigate,useLocation} from 'react-router-dom';
import {Eye,EyeOff,LogIn,Zap} from 'lucide-react';
import {login} from '@/db/firebaseAuth';
import {useAuth} from '@/contexts/AuthContext';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {toast} from 'sonner';
const LoginPage=()=>{const nav=useNavigate(); const location=useLocation(); const {setUser}=useAuth(); const [show,setShow]=useState(false); const [u,setU]=useState(''); const [p,setP]=useState(''); const [loading,setLoading]=useState(false); const from=(location.state as any)?.from?.pathname||'/dashboard';
const s=async(e:any)=>{e.preventDefault(); setLoading(true); const r=await login(u,p); if(r.error){toast.error('Invalid credentials'); setLoading(false); return;} setUser(r.user); toast.success('Welcome back'); nav(from,{replace:true})}
return <div className='min-h-screen flex items-center justify-center bg-background'><div className='w-full max-w-md bg-card border rounded-2xl p-8 shadow-xl'><div className='text-center mb-6'><div className='flex justify-center gap-2 text-2xl font-bold'><Zap/>MetaPay</div><p>Sign in</p></div><form onSubmit={s} className='space-y-4'><Input placeholder='Username' value={u} onChange={e=>setU(e.target.value)}/><div className='relative'><Input type={show?'text':'password'} placeholder='Password' value={p} onChange={e=>setP(e.target.value)}/><button type='button' className='absolute right-3 top-3' onClick={()=>setShow(!show)}>{show?<EyeOff size={16}/>:<Eye size={16}/>}</button></div><Button className='w-full' disabled={loading}>{loading?'Signing in...':<span className='flex gap-2 items-center'><LogIn size={16}/>Login</span>}</Button></form><p className='mt-4 text-center text-sm'>No account? <Link to='/register' className='text-primary'>Register</Link></p></div></div>}
export default LoginPage;
